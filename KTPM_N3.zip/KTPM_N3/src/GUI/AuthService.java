package GUI;
import java.util.HashMap;
import java.util.Map; 
// Lớp AuthService chịu trách nhiệm xử lý xác thực người dùng 
public class AuthService { 
    private Map<String, String> users = new HashMap<>(); // Lưu trữ danh sách tài khoản và mật khẩu 
    public AuthService() { // Khởi tạo danh sách tài khoản hợp lệ 
    users.put("username1", "correctpassword1"); 
    users.put("username2", "correctpassword2"); 
    } 
    // Phương thức đăng nhập, kiểm tra tài khoản và mật khẩu public 
    public User login(String username, String password) { 
        // Kiểm tra xem tài khoản có tồn tại và mật khẩu có chính xác không
        if (users.containsKey(username) && users.get(username).equals(password)) {
            return new User(username); // Trả về đối tượng User nếu đăng nhập thành công } 
        }
		return null;
    }
// Lớp User đại diện cho người dùng đã đăng nhập 
public class User { 
private String username;
public User(String username) { 
    this.username = username; 
} 
public String getUsername() { 
    return username;
    } 
}
}