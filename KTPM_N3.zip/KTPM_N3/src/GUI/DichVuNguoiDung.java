package GUI;
import java.util.HashSet;
import java.util.Set;

public class DichVuNguoiDung {
    private Set<String> danhSachNguoiDung = new HashSet<>();

    public boolean dangKy(String soDienThoai, String maOTP, String matKhau) {
        if (soDienThoai == null || soDienThoai.isEmpty()) {
            throw new IllegalArgumentException("Số điện thoại không được để trống");
        }
        if (maOTP == null || maOTP.isEmpty()) {
            throw new IllegalArgumentException("Mã OTP không được để trống");
        }
        if (matKhau == null || matKhau.isEmpty()) {
            throw new IllegalArgumentException("Mật khẩu không được để trống");
        }
        if (matKhau.length() < 6) {
            throw new IllegalArgumentException("Mật khẩu quá yếu");
        }
        // Kiểm tra người dùng đã tồn tại
        if (danhSachNguoiDung.contains(soDienThoai)) {
            throw new IllegalArgumentException("Người dùng đã tồn tại");
        }

        // Xác nhận OTP
        DichVuOTP dichVuOTP = new DichVuOTP();
        if (!dichVuOTP.kiemTraMaOTP(soDienThoai, maOTP)) {
            throw new IllegalArgumentException("Mã OTP không hợp lệ");
        }

        // Thêm người dùng mới vào danh sách
        danhSachNguoiDung.add(soDienThoai);
        return true;
    }}
