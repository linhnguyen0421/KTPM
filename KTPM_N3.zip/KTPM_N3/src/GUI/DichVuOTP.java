package GUI;

import java.util.HashMap;
import java.util.Map;
public class DichVuOTP {
    private Map<String, String> luuTruOTP = new HashMap<>();
    // Gửi mã OTP
    public boolean guiMaOTP(String soDienThoai) {
        if (soDienThoai == null || soDienThoai.isEmpty()) {
            throw new IllegalArgumentException("Số điện thoại không được để trống");
        }
        // Giả lập mã OTP
        String maOTP = "123456";
        luuTruOTP.put(soDienThoai, maOTP);
        return true;
    }
// Kiểm tra mã OTP
    public boolean kiemTraMaOTP(String soDienThoai, String maOTP) {
        if (!luuTruOTP.containsKey(soDienThoai)) {
            throw new IllegalArgumentException("Số điện thoại không tồn tại");
        }
        String maOTPChinhXac = luuTruOTP.get(soDienThoai);
        return maOTPChinhXac.equals(maOTP);
    }
}
