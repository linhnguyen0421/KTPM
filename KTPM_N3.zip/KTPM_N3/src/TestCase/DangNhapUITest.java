package TestCase;

import static org.junit.jupiter.api.Assertions.*;

import java.io.IOException;
import java.util.ArrayList;

import javax.swing.JPasswordField;
import javax.swing.JTextField;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import Entities.TaiKhoan;
import GUI.DangNhapUI;

class DangNhapUITest {

    DangNhapUI dangNhapUI;

    @BeforeEach
    void setUp() {
        dangNhapUI = new DangNhapUI("Test Login UI");
        dangNhapUI.txtTaiKhoan = new JTextField();
        dangNhapUI.txtMatKhau = new JPasswordField();
    }

    @Test
    void testXuLyDangNhapSuccess() throws IOException, ClassNotFoundException {
        ArrayList<TaiKhoan> accounts = new ArrayList<>();
        accounts.add(new TaiKhoan("admin", "admin123", "Admin"));
        accounts.add(new TaiKhoan("user", "user123", "User"));

        dangNhapUI.txtTaiKhoan.setText("admin");
        dangNhapUI.txtMatKhau.setText("admin123");

        dangNhapUI.xuLyDangNhap(accounts);

        assertEquals("admin", DangNhapUI.username);
    }

    @Test
    void testXuLyDangNhapFailure() throws IOException, ClassNotFoundException {
        ArrayList<TaiKhoan> accounts = new ArrayList<>();
        accounts.add(new TaiKhoan("admin", "admin123", "Admin"));
        accounts.add(new TaiKhoan("user", "user123", "User"));

        dangNhapUI.txtTaiKhoan.setText("invalid");
        dangNhapUI.txtMatKhau.setText("invalid");

        dangNhapUI.xuLyDangNhap(accounts);

        assertEquals("", DangNhapUI.username);
    }

    @Test
    void testEmptyFields() throws IOException, ClassNotFoundException {
        ArrayList<TaiKhoan> accounts = new ArrayList<>();
        accounts.add(new TaiKhoan("admin", "admin123", "Admin"));
        accounts.add(new TaiKhoan("user", "user123", "User"));

        dangNhapUI.txtTaiKhoan.setText("");
        dangNhapUI.txtMatKhau.setText("");

        dangNhapUI.xuLyDangNhap(accounts);

        assertEquals("", DangNhapUI.username);
    }
}
