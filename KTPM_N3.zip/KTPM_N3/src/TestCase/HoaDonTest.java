package TestCase;
import static org.junit.Assert.*;
import org.junit.Before;
import org.junit.Test;

import Entities.HoaDon;
import Entities.Sach;
import Entities.SachTrongGioHang;

import java.util.ArrayList;

public class HoaDonTest {

    private HoaDon hoaDon;
    private ArrayList<SachTrongGioHang> sachMua;

    @Before
    public void setUp() {
        // Khởi tạo danh sách sách mua
        sachMua = new ArrayList<>();

        // Tạo các đối tượng sách	
        Sach sach1 = new Sach("S001", "Sach A", 2023, 100, "TG01", "NXB01", 20000, 10);
        Sach sach2 = new Sach("S002", "Sach B", 2023, 150, "TG02", "NXB02", 30000, 5);

        // Thêm sách vào danh sách
        sachMua.add(new SachTrongGioHang("S01", sach1, 2)); // 2 cuốn A
        sachMua.add(new SachTrongGioHang("S02", sach2, 3)); // 3 cuốn B

        // Tạo đối tượng hóa đơn
        hoaDon = new HoaDon("HD001", "2024-11-16", "Nguyen Van A", sachMua, 5, 130000.0);
    }

    @Test
    public void testHoaDonCreation() {
        // Kiểm tra thông tin khi tạo hóa đơn
        assertEquals("HD001", hoaDon.getMaHD());
        assertEquals("2024-11-16", hoaDon.getNgayGiaoDich());
        assertEquals("Nguyen Van A", hoaDon.getTenKH());
        assertEquals(2, hoaDon.getSachMua().size());
        assertEquals(5, hoaDon.getSoLuong());
        assertEquals(130000.0, hoaDon.getThanhTien(), 0.01);
    }

    @Test
    public void testSettersAndGetters() {
        // Thay đổi thông tin hóa đơn
        hoaDon.setMaHD("HD002");
        hoaDon.setNgayGiaoDich("2024-11-17");
        hoaDon.setTenKH("Tran Thi B");
        hoaDon.setSoLuong(5);
        hoaDon.setThanhTien(500.0);

        // Kiểm tra thông tin sau khi thay đổi
        assertEquals("HD002", hoaDon.getMaHD());
        assertEquals("2024-11-17", hoaDon.getNgayGiaoDich());
        assertEquals("Tran Thi B", hoaDon.getTenKH());
        assertEquals(5, hoaDon.getSoLuong());
        assertEquals(500.0, hoaDon.getThanhTien(), 0.01);
    }

    @Test
    public void testSachMuaDetails() {
        // Kiểm tra chi tiết sách đầu tiên
        SachTrongGioHang sach1 = hoaDon.getSachMua().get(0);
        assertEquals("S01", sach1.getMaTaiKhoan());
        assertEquals("S001", sach1.getSachDaChon().getMaSach());
        assertEquals(2, sach1.getSoLuong());
        assertEquals(20000.0, sach1.getSachDaChon().getDonGia(), 0.01);

        // Kiểm tra chi tiết sách thứ hai
        SachTrongGioHang sach2 = hoaDon.getSachMua().get(1);
        assertEquals("S02", sach2.getMaTaiKhoan());
        assertEquals("S002", sach2.getSachDaChon().getMaSach());
        assertEquals(3, sach2.getSoLuong());
        assertEquals(30000.0, sach2.getSachDaChon().getDonGia(), 0.01);
    }
}
