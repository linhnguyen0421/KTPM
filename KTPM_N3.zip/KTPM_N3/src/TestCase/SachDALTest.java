package TestCase;
import Entities.Sach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import DAL.SachDAL;

import java.io.IOException;
import java.util.ArrayList;
import static org.junit.jupiter.api.Assertions.*;
public class SachDALTest {
   private ArrayList<Sach> mockSachList;
   private Sach sach1, sach2, sach3;
   @BeforeEach
   void setUp() {
       // Tạo danh sách sách giả
       mockSachList = new ArrayList<>();
       sach1 = new Sach("S001", "Sach A", 2023, 100, "TG01", "NXB01", 20000, 10);
       sach2 = new Sach("S002", "Sach B", 2023, 150, "TG02", "NXB02", 30000, 5);
       sach3 = new Sach("S003", "Sach C", 2024, 150, "TG03", "NXB03", 40000, 5);
       mockSachList.add(sach1);
       mockSachList.add(sach2);
       mockSachList.add(sach3);
   }
   @Test 
   void testGetSachByName() {
       // Tìm sách theo tên trong danh sách mock
       Sach result = null;
       for (Sach sach : mockSachList) {
           if (sach.getTenSach().equals("Sach A")) {
               result = sach;
               break;
           }
       }
       // Kiểm tra kết quả trả về
       assertNotNull(result, "Không tìm thấy sách theo tên");
       assertEquals("S001", result.getMaSach(), "Mã sách không khớp");
       assertEquals("Sach A", result.getTenSach(), "Tên sách không khớp");
   }
   @Test
   void testGetSachByMaSach() {
       // Tìm sách theo mã sách trong danh sách mock
       Sach result = null;
       for (Sach sach : mockSachList) {
           if (sach.getMaSach().equals("S001")) {
               result = sach;
               break;
           }
       }
       // Kiểm tra kết quả trả về
       assertNotNull(result, "Không tìm thấy sách theo mã");
       assertEquals("S001", result.getMaSach(), "Mã sách không khớp");
       assertEquals("Sach A", result.getTenSach(), "Tên sách không khớp");
   }
   @Test
   void testInsertSach() throws IOException {
       // Kiểm tra thêm sách mới vào danh sách
       Sach newSach = new Sach("S008", "Sach F", 2023, 150, "TG02", "NXB02", 30000, 5);
       boolean inserted = true;
       for (Sach sach : mockSachList) {
           if (sach.getMaSach().equals(newSach.getMaSach())) {
               inserted = false;
               break;
           }
       }
       if (inserted) {
           mockSachList.add(newSach);
       }
       assertTrue(inserted);
       assertEquals(4, mockSachList.size());
       assertEquals(newSach, mockSachList.get(3));
   }
   @Test
   void testDeleteSach() throws IOException {
       // Chuẩn bị danh sách sách giả
       Sach sachToDelete = new Sach("S001", "Sach A", 2023, 100, "TG01", "NXB01", 20000, 10);
       // Gọi hàm xóa sách
       boolean isDeleted = SachDAL.delete(mockSachList, sachToDelete);
       // Kiểm tra kết quả
       assertTrue(isDeleted, "Xóa sách thất bại");
       assertEquals(2, mockSachList.size(), "Số lượng sách sau khi xóa không đúng");
       assertNull(SachDAL.GetSach_TheoMa("S01"), "Sách đã xóa vẫn tồn tại");
   }
   @Test
   void testUpdateSach() throws IOException {
       // Kiểm tra cập nhật thông tin sách
       String maSachToUpdate = "S002";
       Sach updatedSach = new Sach("S002", "Sach B", 2023, 150, "TG02", "NXB02", 30000, 5);
       boolean updated = false;
       for (int i = 0; i < mockSachList.size(); i++) {
           if (mockSachList.get(i).getMaSach().equals(maSachToUpdate)) {
               mockSachList.set(i, updatedSach);
               updated = true;
               break;
           }
       }
       assertTrue(updated);
       assertEquals(updatedSach, mockSachList.get(1));
   }
}

