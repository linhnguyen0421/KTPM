package TestCase;
import static org.junit.Assert.*; 
import java.io.IOException; 
import java.util.ArrayList; 
import java.util.HashMap;
import org.junit.Before;
import org.junit.Test;

import DAL.TacGiaDAL;
import Entities.TacGia; 
public class TacGiaDALTest {
	private ArrayList<TacGia> tacGiaList; 
	@Before
	public void setUp() throws IOException, ClassNotFoundException { 
		tacGiaList = TacGiaDAL.show(); 
		}
	@Test
	public void testShow() throws IOException, ClassNotFoundException { 
		ArrayList<TacGia> result = TacGiaDAL.show(); 
		assertNotNull(result); assertFalse(result.isEmpty()); 
		} 
	@Test
	public void testHashMapTG() { 
		HashMap<String, String> result = TacGiaDAL.hashMapTG(); 
		assertNotNull(result); 
		assertFalse(result.isEmpty()); 
		}
	@Test 
	public void testGetTenTG() { 
		String maTG = "TG01"; // Đảm bảo mã tác giả này tồn tại trong danh sách của bạn 
		String tenTG = TacGiaDAL.GetTenTG(maTG); 
		assertEquals("Nguyen Van A", tenTG); // Thay đổi tên tác giả tương ứng
		}
	@Test
	public void testInsert() throws IOException { 
		TacGia newTG = new TacGia("TG02", "Nguyen Van B",0); 
		boolean isInserted = TacGiaDAL.insert(tacGiaList, newTG); 
		assertTrue(isInserted); // Kiểm tra tác giả mới có trong danh sách không 
		TacGia insertedTG = tacGiaList.stream().filter(tg -> tg.getMaTG().equals(newTG.getMaTG())).findFirst().orElse(null); 
		assertNotNull(insertedTG);
		assertEquals(newTG.getMaTG(), insertedTG.getMaTG()); 
		assertEquals(newTG.getTenTG(), insertedTG.getTenTG());
		}
	@Test
	public void testUpdate() throws IOException { 
		TacGia existingTG = tacGiaList.get(0); 
		String newTenTG = "Nguyen Van C"; 
		existingTG.setTenTG(newTenTG); 
		boolean isUpdated = TacGiaDAL.update(tacGiaList, existingTG);
		assertTrue(isUpdated); // Kiểm tra tên tác giả được cập nhật
		TacGia updatedTG = tacGiaList.stream().filter(tg -> tg.getMaTG().equals(existingTG.getMaTG())).findFirst().orElse(null);
		assertEquals(newTenTG, updatedTG.getTenTG());
		}
	@Test
	public void testDelete() throws IOException { 
		TacGia delTG = tacGiaList.get(0);
		boolean isDeleted = TacGiaDAL.delete(tacGiaList, delTG); 
		assertTrue(isDeleted); // Kiểm tra tác giả đã được xóa khỏi danh sách 
		TacGia deletedTG = tacGiaList.stream().filter(tg -> tg.getMaTG().equals(delTG.getMaTG())).findFirst().orElse(null);
		assertNull(deletedTG); 
		}
}